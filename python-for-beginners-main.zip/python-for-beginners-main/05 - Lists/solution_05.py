fruits = {"banana": 2, "apple": 3, "kiwi": 4}
print(fruits.items())
